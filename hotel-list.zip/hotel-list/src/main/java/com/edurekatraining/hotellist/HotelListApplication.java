package com.edurekatraining.hotellist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelListApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelListApplication.class, args);
	}

}
